# tn-collaboration

## How to run the widgets independently 


### Prerequisite

Have the following installed: 
 - Install 'npm install -g http-server'

### To run the widget

 - Go to the location where the widget is location
 - Go to App folder and run http-server in cmd. 
 - Copy the URL and open it in browser to run the app
