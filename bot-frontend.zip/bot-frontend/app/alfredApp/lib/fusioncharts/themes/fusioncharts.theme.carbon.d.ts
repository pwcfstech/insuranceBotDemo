
import { FusionChartStatic } from "fusioncharts";

declare namespace Carbon {}
declare var Carbon: (H: FusionChartStatic) => FusionChartStatic;
export = Carbon;
export as namespace Carbon;

