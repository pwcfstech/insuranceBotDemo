
import { FusionChartStatic } from "fusioncharts";

declare namespace Ssgrid {}
declare var Ssgrid: (H: FusionChartStatic) => FusionChartStatic;
export = Ssgrid;
export as namespace Ssgrid;

